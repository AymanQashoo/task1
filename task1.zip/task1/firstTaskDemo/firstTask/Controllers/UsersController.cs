﻿using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using System.Threading.Tasks;
using System.Text;  // Needed for StringContent

namespace firstTask.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly HttpClient _httpClient;

        public UsersController()
        {
            _httpClient = new HttpClient();
        }

        // GET: api/<UsersController>
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            string url = "https://my-json-server.typicode.com/AymanQashoo/task1/db";
            try
            {
                HttpResponseMessage response = await _httpClient.GetAsync(url);
                response.EnsureSuccessStatusCode();
                string responseBody = await response.Content.ReadAsStringAsync();
                return Ok(responseBody);
            }
            catch (HttpRequestException e)
            {
                return StatusCode(500, e.Message);  // Internal Server Error
            }
        }

        // GET api/<UsersController>/posts/5
        [HttpGet("posts/{id}")]
        public async Task<IActionResult> GetPost(int id)
        {
            string url = $"https://my-json-server.typicode.com/AymanQashoo/task1/posts/{id}";
            try
            {
                HttpResponseMessage response = await _httpClient.GetAsync(url);
                response.EnsureSuccessStatusCode();
                string responseBody = await response.Content.ReadAsStringAsync();
                return Ok(responseBody);
            }
            catch (HttpRequestException e)
            {
                return StatusCode(500, e.Message);
            }
        }

        // GET api/<UsersController>/comments/5
        [HttpGet("comments/{id}")]
        public async Task<IActionResult> GetComment(int id)
        {
            string url = $"https://my-json-server.typicode.com/AymanQashoo/task1/comments/{id}";
            try
            {
                HttpResponseMessage response = await _httpClient.GetAsync(url);
                response.EnsureSuccessStatusCode();
                string responseBody = await response.Content.ReadAsStringAsync();
                return Ok(responseBody);
            }
            catch (HttpRequestException e)
            {
                return StatusCode(500, e.Message);
            }
        }

        // POST api/<UsersController>/posts
        [HttpPost("posts")]
        public async Task<IActionResult> PostPost([FromBody] JsonElement content)
        {
            string url = "https://my-json-server.typicode.com/AymanQashoo/task1/posts";
            try
            {
                var jsonContent = new StringContent(content.ToString(), Encoding.UTF8, "application/json");
                HttpResponseMessage response = await _httpClient.PostAsync(url, jsonContent);
                response.EnsureSuccessStatusCode();
                string responseBody = await response.Content.ReadAsStringAsync();
                return Ok(responseBody);
            }
            catch (HttpRequestException e)
            {
                return StatusCode(500, e.Message);
            }
        }

        // POST api/<UsersController>/comments
        [HttpPost("comments")]
        public async Task<IActionResult> PostComment([FromBody] JsonElement content)
        {
            string url = "https://my-json-server.typicode.com/AymanQashoo/task1/comments";
            try
            {
                var jsonContent = new StringContent(content.ToString(), Encoding.UTF8, "application/json");
                HttpResponseMessage response = await _httpClient.PostAsync(url, jsonContent);
                response.EnsureSuccessStatusCode();
                string responseBody = await response.Content.ReadAsStringAsync();
                return Ok(responseBody);
            }
            catch (HttpRequestException e)
            {
                return StatusCode(500, e.Message);
            }
        }

        // PUT api/<UsersController>/posts/5
        [HttpPut("posts/{id}")]
        public async Task<IActionResult> PutPost(int id, [FromBody] JsonElement content)
        {
            string url = $"https://my-json-server.typicode.com/AymanQashoo/task1/posts/{id}";
            try
            {
                var jsonContent = new StringContent(content.ToString(), Encoding.UTF8, "application/json");
                HttpResponseMessage response = await _httpClient.PutAsync(url, jsonContent);
                response.EnsureSuccessStatusCode();
                string responseBody = await response.Content.ReadAsStringAsync();
                return Ok(responseBody);
            }
            catch (HttpRequestException e)
            {
                return StatusCode(500, e.Message);
            }
        }

        // PUT api/<UsersController>/comments/5
        [HttpPut("comments/{id}")]
        public async Task<IActionResult> PutComment(int id, [FromBody] JsonElement content)
        {
            string url = $"https://my-json-server.typicode.com/AymanQashoo/task1/comments/{id}";
            try
            {
                var jsonContent = new StringContent(content.ToString(), Encoding.UTF8, "application/json");
                HttpResponseMessage response = await _httpClient.PutAsync(url, jsonContent);
                response.EnsureSuccessStatusCode();
                string responseBody = await response.Content.ReadAsStringAsync();
                return Ok(responseBody);
            }
            catch (HttpRequestException e)
            {
                return StatusCode(500, e.Message);
            }
        }

        // DELETE api/<UsersController>/posts/5
        [HttpDelete("posts/{id}")]
        public async Task<IActionResult> DeletePost(int id)
        {
            string url = $"https://my-json-server.typicode.com/AymanQashoo/task1/posts/{id}";
            try
            {
                HttpResponseMessage response = await _httpClient.DeleteAsync(url);
                response.EnsureSuccessStatusCode();
                return Ok($"Post {id} deleted successfully.");
            }
            catch (HttpRequestException e)
            {
                return StatusCode(500, e.Message);
            }
        }

        // DELETE api/<UsersController>/comments/5
        [HttpDelete("comments/{id}")]
        public async Task<IActionResult> DeleteComment(int id)
        {
            string url = $"https://my-json-server.typicode.com/AymanQashoo/task1/comments/{id}";
            try
            {
                HttpResponseMessage response = await _httpClient.DeleteAsync(url);
                response.EnsureSuccessStatusCode();
                return Ok($"Comment {id} deleted successfully.");
            }
            catch (HttpRequestException e)
            {
                return StatusCode(500, e.Message);
            }
        }
    }
}
